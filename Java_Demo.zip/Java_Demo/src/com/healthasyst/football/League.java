package com.healthasyst.football;

public class League {

	public static void main(String[] args) {

		// intilaize the player object and load the data
		Player player1 = new Player();
		player1.playerName = "Raina";

		Player player2 = new Player();
		player2.playerName = "John";

		Player player3 = new Player();
		player3.playerName = "Dhoni";

		Player[] team1Players = new Player[3];
		team1Players[0] = player1;
		team1Players[1] = player2;
		team1Players[2] = player3;

		Team team1 = new Team();
		team1.teamName = "CSK";
		team1.playerArray = team1Players;
		

		// intilaize the player object and load the data
		Player player4 = new Player();
		player1.playerName = "kholi";

		Player player5 = new Player();
		player2.playerName = "Kaif";

		Player player6 = new Player();
		player3.playerName = "Yuvi";

	Player[] team2Players = {player4,player5,player6};

		Team team2 = new Team();
		team2.teamName = "RCB";
		team2.playerArray = team2Players;
			
		
		// " cannot be done as passing value initilaize" team2.playerArray  = {player1,player2,player3}; 
		
		System.out.println("Team Name "+ team1.teamName);
		System.out.println("Team1 players name are ");
		
		for (Player player : team1Players) {
			System.out.println(player.playerName);
			
		}

		System.out.println("--------------------------------- ");
		
		System.out.println("Team Name "+ team2.teamName);
		System.out.println("Team2 players name are ");
		
		for (Player player : team2Players) {
			System.out.println(player.playerName);
			
		}

	}

}
