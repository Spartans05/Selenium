package com.healthasyst.football;

public class Team {

	public String teamName ;
	public Player[] playerArray ;
}