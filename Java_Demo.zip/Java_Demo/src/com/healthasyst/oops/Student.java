package com.healthasyst.oops;

public class Student {

	private int studentId;
	private String studentName;
	private String studentMailId;
	private double studentPercentage;
	private static String schoolName;
	private static int counter = 101;
	
	public Student() {
		studentId = counter;
		counter = counter + 1;
		
	}


	public Student(String studentName) {
		studentId = counter;
		counter = counter + 1;
		this.studentName = studentName;
	}

	public Student(String studentName, String studentMailId) {
		studentId = counter;
		counter = counter + 1;
		this.studentMailId = studentMailId;
	}

	public double getStudentPercentage() {

		return this.studentPercentage;

	}

	public void setStudentPercentage(double studentPercentage) {

		if (studentPercentage >= 0 && studentPercentage <= 100) {
			this.studentPercentage = studentPercentage;

		}

		else {
			System.out.println("Invalid Percentage");
		}

	}
}
