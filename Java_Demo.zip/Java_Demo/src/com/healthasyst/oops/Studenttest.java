package com.healthasyst.oops;

public class Studenttest {

	public static void main(String[] args) {
		
		
		Student std1 = new Student();
		Student std2 = new Student();
		Student std3 = new Student();
		
		
		std1.setStudentPercentage(85.5);
		System.out.println("student percenatge is " + std1.getStudentPercentage());
		
	}

}
