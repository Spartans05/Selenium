package com.healthasyst.methodoverloading;

public class calTest {

	public static void main(String[] args) {
		
		Calculator cal = new Calculator();
		cal.add(10, 10);

	}

}
