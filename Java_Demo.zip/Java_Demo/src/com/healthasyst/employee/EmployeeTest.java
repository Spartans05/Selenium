package com.healthasyst.employee;

public class EmployeeTest {

	public static void main(String[] args) {

		
		Employee.companyName = "Amazon";
		
		
		Employee emp1 = new Employee();
		Employee emp2 = new Employee();
		Employee emp3 = new Employee();

		emp1.empID = 101;
		emp1.empName = "Watson";
		emp1.empSalary = 5000;
	

		emp2.empID = 102;
		emp2.empName = "Lara";
		emp2.empSalary = 6000;
		

		emp3.empID = 103;
		emp3.empName = "sachin";
		emp3.empSalary = 7000;
		
		System.out.println(emp1);
		System.out.println(emp2);
		System.out.println(emp3);
		System.out.println("------------------------------------------");
		System.out.println(" static methods");
		// Static pass by reference
		Employee.printEmployeeDetails(emp1); 
		Employee.printEmployeeDetails(emp2);
		Employee.printEmployeeDetails(emp3);
		System.out.println("------------------------------------------");
		System.out.println("Non static methods");
		// instance method 
		emp1.printEmployeeDetail();//pass by reference
		emp2.printEmployeeDetail();
		emp3.printEmployeeDetail();
	}

}
