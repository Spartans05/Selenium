package com.healthasyst.employee;

public class Employee {

	public int empID ;
	public String empName;
	public double empSalary;
	public static  String companyName;
	
	// Print Employee details
	
	public static void printEmployeeDetails(Employee emp) {
		
		System.out.println(emp.empID);
		System.out.println(emp.empName);
		System.out.println(emp.empSalary);
		System.out.println(Employee.companyName);
		// if it is in same class directly u can call static variable name
		System.out.println(companyName);
		System.out.println("------------------------------------");
	}
	
     // Instance method 
	public void printEmployeeDetail() {
		System.out.println(this.empID); // this keyword can be used in any method for  check current address
		System.out.println(empID);
		System.out.println(empName);
		System.out.println(empSalary);
		System.out.println(Employee.companyName);
		// if it is in same class directly u can call static variable name
		System.out.println(companyName);
		System.out.println("------------------------------------");
	}
	
	
	
	
}
