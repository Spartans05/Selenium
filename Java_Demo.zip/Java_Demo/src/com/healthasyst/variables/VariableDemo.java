package com.healthasyst.variables;

public class VariableDemo {
	
	public static int as = 10; // static or class variable 
	public int aNS = 100; // non static or instance variable

	public static int bs = 20; 
	public int bNS = 200;
	
	public static void main(String[] args) {

		VariableDemo.as = 30;

		System.out.println(VariableDemo.as);
		System.out.println(VariableDemo.bs);

		VariableDemo var = new VariableDemo();
		System.out.println("instance variable address " + var);
		System.out.println(var.aNS);
		System.out.println(var.bNS);

		VariableDemo var1 = new VariableDemo();
		var1.aNS = 5000;
		System.out.println("instance variable address " + var);
		System.out.println(var1.aNS);
		System.out.println(var1.bNS);

		var = null; // It is used for garbage collection

		var = var1; // It will point to var address
		

	}

}
