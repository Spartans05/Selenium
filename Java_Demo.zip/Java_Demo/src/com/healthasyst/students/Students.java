package com.healthasyst.students;

public class Students {

	private String rollNumber;
    private String name;
    private String mailId;
    private double percentage;
    private static String schoolName ="Global School";

    
 public Students(String rollNumber, String name, String mailId, double percentage){
       
     //set object properties from the arguments/parameters
     this.rollNumber = rollNumber;
     this.name = name;
     this.mailId = mailId;
     this.percentage = percentage;
 }
 
	public void display() {

		System.out.println("Roll Number is :" + rollNumber);
		System.out.println("Name is : " + name);	
		System.out.println("Mail id  is : " + mailId);	
		System.out.println("Percentage  is : " + percentage);	
		System.out.println("School Name  is : " + schoolName);	
		System.out.println("----------------------------------------------");	

	}
	
	 
 
}





