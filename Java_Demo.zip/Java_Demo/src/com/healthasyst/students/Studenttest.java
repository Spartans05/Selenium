package com.healthasyst.students;

public class Studenttest {

	public static void main(String[] args) {
		
		
		Students std1 = new Students("M1001","jack","jack@gmail.com",45.2);
		Students std2 = new Students("M1002","peter","peter@gmail.com",85.2);
		Students std3 = new Students("M1003","mark","mark@gmail.com",56.5);
		
		std1.display();
		std2.display();
		std3.display();
	}

}
