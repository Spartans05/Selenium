package com.healthasyst.inheritance;

class Parent {
	
public int pAge;
private String pName;

public Parent ( )
{
	System.out.println("Parent Constructor");
	pAge = 75;
}

	public void parentStyle()
	{
		System.out.println("Parent Style !");
	}
	
}

class Child extends Parent {

	public int cAge;
	
	
	public Child ()
	{
		System.out.println("Child Constructor");
		cAge = 45;
	}
	
	public void childStyle()
	{
		System.out.println("child Style  !!");
	}
	
}


public class InheritanceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Child cobj = new Child();
		System.out.println(cobj.pAge);
	    System.out.println(cobj.cAge);
	    cobj.parentStyle();
	    cobj.childStyle();
	}

}
