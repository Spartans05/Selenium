package com.ha.seleniumassignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class Nasscom {
	
	private static  WebDriver driver;
	
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./Library/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.get("https://nasscom.in/");
		
		driver.findElement(By.xpath("//a[normalize-space(text())='New User']")).click();
				
		driver.findElement(By.id("edit-field-fname-reg")).sendKeys("admin");
		driver.findElement(By.id("edit-field-lname")).sendKeys("pass");
		driver.findElement(By.id("edit-mail")).sendKeys("admin@gmail.com");
		driver.findElement(By.id("edit-field-company-name-registration")).sendKeys("Amazon");
		
		Select selectJob = new Select(driver.findElement(By.id("edit-field-business-focus-reg")));
		selectJob.selectByVisibleText("IT Consulting");
				
		driver.findElement(By.id("edit-submit--2")).click();
			
		driver.quit();
	
	}

}
