package com.ha.runner;

import com.ha.base.Person;
import com.ha.groups.Professor;
import com.ha.groups.students;

public class Runner {

	public static void main(String[] args) {
		
		Person.setSchoolName("Global School");
		Person.setschoolAddress("Delhi Public school");

		students std1 = new students();
		std1.setName("LARA");
		std1.setPhoneNumber(9123456789L);
		std1.setMaildId("Lara@gmail.com");
		std1.setAddress("Pose Garden Chennai");
		std1.setcourseCode("AR01");
		std1.setPhoneNumber(9123456789L);
		std1.setStudentPercentage(92);
		std1.printStudentDetails();
		std1.providecertification();
		
		
				
		students std2 = new students();
		std2.setName("Watson");
		std2.setPhoneNumber(9765432111L);
		std1.setMaildId("Watson@gmail.com");
		std1.setAddress("Pose Garden Chennai");
		std1.setcourseCode("AR02");
		std2.setStudentPercentage(44);
		std2.printStudentDetails();
		std2.providecertification();
	   

		Professor Prof=new Professor();
		Prof.setName("GilChrist");
		Prof.setPhoneNumber(9765437711L);
		Prof.setDepartmentName("DP101");
		Prof.setMaildId("Watson@gmail.com");
		Prof.setAddress("Pose Garden Chennai");
		Prof.setDepartmentName("Electronics");
		Prof.printProfessorDetail();
	}

}
