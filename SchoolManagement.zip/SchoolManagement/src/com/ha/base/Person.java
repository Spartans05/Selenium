package com.ha.base;

public class Person {

	private String Name;
	private long phoneNumber;
	private String mailId;
	private String Address;
	private static String schoolName;
	private static String schoolAddress;

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		if (String.valueOf(phoneNumber).length() == 10) {
			this.phoneNumber = phoneNumber;
		}

		else {
			System.out.println("Invalid Phonenumber !!");
		}
	}

	public void setMaildId(String mailId) {
		if (mailId.contains("@")) {
			this.mailId = mailId;
		} else {
			System.out.println("Inputted invalid mail id");
		}

		this.mailId = mailId;
	}

	public String getMailId() {
		return mailId;
	}

	public void setAddress(String Address) {
		this.Address = Address;
	}

	public String getAddress() {
		return Address;
	}

	public static void setSchoolName(String schoolName) {
		Person.schoolName = schoolName;
	}

	public static String getSchoolName() {
		return schoolName;
	}

	public static void setschoolAddress(String schoolAddress) {
		Person.schoolAddress = schoolAddress;
	}

	public static String getschoolAddress() {
		return schoolAddress;
	}

}
