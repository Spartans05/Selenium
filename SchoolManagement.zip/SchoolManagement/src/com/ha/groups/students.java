package com.ha.groups;

import com.ha.base.Person;

public class students extends Person {

	private int studentId;
	private double studentPercentage;
	private String courseCode;
	private static int counter = 101;
	
	public students() {
		setStudentId(counter);
		counter = counter + 1;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		if (studentId > 100) {
			this.studentId = studentId;
		} else {

			System.out.println("Invalid studentid");
		}

	}

	public double getStudentPercentage() {

		return this.studentPercentage;

	}

	public void setStudentPercentage(double studentPercentage) {

		if (studentPercentage >= 0 && studentPercentage <= 100) {
			this.studentPercentage = studentPercentage;

		}

		else {
			System.out.println("Invalid Percentage");
		}

	}

	public void setcourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	public String getcourseCode() {
		return courseCode;
	}

	public void printStudentDetails() {
			
		System.out.println("Student Id is " + this.getStudentId());
		System.out.println("Student Name is " + super.getName());
		System.out.println("Student Phone Number is " + super.getPhoneNumber());
		System.out.println("Student Mailid is "+super.getMailId());
		System.out.println("Student Address is "+super.getAddress());
		System.out.println("School Name is "+super.getSchoolName());
		System.out.println("School Address is "+super.getschoolAddress());
		System.out.println("Student Percentage is " + getStudentPercentage());

	}

	public void providecertification() {
		System.out.println("Provide certification " + super.getName());
		if (this.studentPercentage >= 50) {
			System.out.println("Congrats Passed !");
			System.out.println("------------------------------------------------");
		} else {
			System.out.println("Failed try again");
			System.out.println("------------------------------------------------");
		}

	}

}
