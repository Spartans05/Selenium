package com.ha.groups;

import com.ha.base.Person;

public class Professor extends Person {
	
	private int professorId;
	private String departmentName;
	private static int counter = 501;
	
	
	public Professor() {
		setprofessorId(counter);
		counter = counter + 1;
	}

			
	
	public int getprofessorId() {
		return professorId;
	}

	public void setprofessorId(int professorId) {
		if (professorId > 500) {
			this.professorId = professorId;
		} else {

			System.out.println("Invalid Professorid");
		}

	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public void printProfessorDetail() {
		System.out.println("Professor Name " + super.getName());
		System.out.println("Professor id is "+this.getprofessorId());
		System.out.println("Professor Phone number is "+super.getPhoneNumber());
		System.out.println("Professor mailid is "+super.getMailId());
		System.out.println("Professor Address is "+super.getAddress());
		System.out.println("School Name is "+super.getSchoolName());
		System.out.println("School Address is "+super.getschoolAddress());
		System.out.println("Professor belongs to "+this.getDepartmentName());
		System.out.println("--------------------------------");
	}

}

